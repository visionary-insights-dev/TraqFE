# ScholarLink Frontend

## Project
Multi-tenant SaaS Program & Scholarship Management Platform.
Pilot client: Talent Makers Foundation (TMF), Lagos, Nigeria.

## Stack
- Next.js (App Router) + React + TypeScript (strict)
- Tailwind CSS
- TanStack Query (server state)
- Socket.IO client (real-time notifications)
- PWA (service worker + manifest)
- Vercel hosting
- Monorepo path: `/apps/web`

## Three Role Experiences — Build All Three Separately
- **Super Admin** — information density, desktop-first, sidebar nav
- **Mentor** — speed + focused tasks, mobile + tablet
- **Scholar** — simplicity + mobile-first, bottom nav on mobile

## Code Rules
- TypeScript strict mode, no `any`
- Prefer named exports over default exports for components
- All API calls through TanStack Query — no raw `fetch` in components
- UTC from API, display in org timezone (default `Africa/Lagos`)
- Client validation is UX only — never a security boundary
- Offline writes (Mark as Done, attendance, verification) must fail with a clear banner
- No `organizationId` sent from client to API — auth session derives it server-side

## API
- Base: `/api/v1`
- Success: `{ success: true, data: {}, meta: {} }`
- Error: `{ success: false, error: { code: "MACHINE_CODE", message: "..." } }`
- Pagination: `?page=1&limit=25` → `meta.total`, `meta.totalPages`
- Async ops return `202 Accepted` → poll for completion

## Key Business Rules
- Progress = 70% assignments + 30% attendance (org-configurable)
- Assignment edit window = 60 min after publish → show countdown → replace Edit with "Request Change"
- Excused attendance excluded from rate calculation
- Late submissions: 20% credit deduction (org-configurable)
- Scholars cannot see other scholars' progress, attendance %, assignments, or mentor feedback
- Invitation links expire after 48 hours
- File upload max: 20 MB
- Assignment deadlines are mandatory

## Assignment Status Flow
`NOT_STARTED → IN_PROGRESS → PENDING_VERIFICATION → VERIFIED / VERIFIED_LATE`
`PENDING_VERIFICATION → RESUBMISSION_REQUIRED → (scholar resubmits) → PENDING_VERIFICATION`
`(any) → OVERDUE (parallel, time-based)`

## Commands
- Dev: `npm run dev`
- Build: `npm run build`
- Lint: `npm run lint`
- Type check: `npm run type-check`
- Test: `npm run test`
- E2E: `npm run test:e2e`

## File Structure
```
src/
  app/                  # Next.js App Router pages
    (admin)/            # Super Admin layout group
    (mentor)/           # Mentor layout group
    (scholar)/          # Scholar layout group
    (auth)/             # Login, registration, invitations
  components/
    ui/                 # Base design system components
    admin/              # Admin-specific components
    mentor/             # Mentor-specific components
    scholar/            # Scholar-specific components
    shared/             # Cross-role components
  hooks/                # Custom React hooks + TanStack Query hooks
  lib/
    api/                # API client + query functions
    utils/              # Utility functions
    types/              # Local type extensions (shared types from @scholarlink/types)
  stores/               # Auth session store
```

## Do Not
- Do not duplicate types that exist in `@scholarlink/types`
- Do not store auth tokens in localStorage
- Do not hard-code hex colours — use Tailwind tokens
- Do not write API logic in components — put it in `src/hooks/` or `src/lib/api/`
- Do not build one generic dashboard with hidden menu items per role
