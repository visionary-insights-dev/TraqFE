# Traq FE — Build Progress

> This file is read by AI coding agents alongside AGENTS.md.
> Update it every time you finish a screen, component, or decision.
> Commit it with your PR so the next dev picks up exactly where you left off.

---

## Current Status

**Phase:** Project setup
**Last updated by:** [your name]
**Last updated:** 2026-08-28

---

## What's Done

### Project Setup
- [ ] Next.js scaffolded (`create-next-app`)
- [ ] Dependencies installed (TanStack Query, Socket.IO, Zod, etc.)
- [ ] Folder structure created (`src/app`, `src/components`, etc.)
- [ ] API client (`src/lib/api/client.ts`)
- [ ] Auth store (`src/stores/auth.ts`)
- [ ] Providers wrapper (`src/components/shared/Providers`)
- [ ] Test utils (`src/test-utils/index.tsx`)
- [ ] Jest configured
- [ ] Playwright configured

### Auth Screens (Scholar Mobile)
- [ ] Sign In (`src/app/(auth)/sign-in/`)
- [ ] Magic Link (`src/app/(auth)/magic-link/`)
- [ ] Magic Link Sent (`src/app/(auth)/magic-link-sent/`)
- [ ] Onboarding: Profile Setup (`src/app/(auth)/onboarding/`)
- [ ] Onboarding: Success (`src/app/(auth)/onboarding/success/`)

### Scholar Screens (Mobile)
- [ ] Dashboard (`src/app/(scholar)/dashboard/`)
- [ ] My Courses & Progress (`src/app/(scholar)/courses/`)
- [ ] Assignments List (`src/app/(scholar)/assignments/`)
- [ ] Assignment Detail (`src/app/(scholar)/assignments/[id]/`)
- [ ] Resources (`src/app/(scholar)/resources/`)
- [ ] My Cohort (`src/app/(scholar)/cohort/`)
- [ ] Chat (`src/app/(scholar)/chat/`)
- [ ] Profile & Settings (`src/app/(scholar)/profile/`)
- [ ] Notifications (`src/app/(scholar)/notifications/`)

### Mentor Screens (TBD — not yet in Figma)
- [ ] Dashboard
- [ ] My Scholars
- [ ] Assignments (create/verify)
- [ ] Attendance Roster
- [ ] Meetings

### Admin Screens (TBD — not yet in Figma)
- [ ] Dashboard
- [ ] Programs
- [ ] Courses
- [ ] People (Scholars / Mentors)
- [ ] Sort or Pair
- [ ] Reports
- [ ] Settings

---

## What's In Progress

> Move items here when you start them. Include your name so others don't duplicate.

<!-- Example:
- **Sign In screen** — @yourname — started 2026-08-28
-->

Nothing in progress yet.

---

## Decisions Made

> Log any decision that affects how other devs build. If you chose something non-obvious, explain why.

| Date | Decision | Why |
|---|---|---|
| 2026-08-28 | Scholar screens are mobile-first (393px) | Figma only has mobile frames |
| 2026-08-28 | Auth uses email + password + magic link | Per Sign In screen in Figma |
| 2026-08-28 | Product name in UI is "TRAQ" | Figma headers say TRAQ, not ScholarLink — confirm with designer |

---

## Known Gaps / Blockers

| Gap | Owner | Status |
|---|---|---|
| Mentor screens missing from Figma | Designer | Blocking Mentor build |
| Admin screens missing from Figma | Designer | Blocking Admin build |
| Assignment Detail screen missing from Figma | Designer | Blocking detail view |
| "TRAQ" vs "ScholarLink" naming inconsistency | PM | Needs decision |

---

## Figma Reference

| Screen | Figma Node ID | Page |
|---|---|---|
| Sign In | `2362:7462` | Scholar Panel (Mobile) |
| Magic Link | `2362:7432` | Scholar Panel (Mobile) |
| Magic Link Sent | `2362:7521` | Scholar Panel (Mobile) |
| Onboarding: Profile Setup | `2362:7282` | Scholar Panel (Mobile) |
| Onboarding: Success | `2362:7351` | Scholar Panel (Mobile) |
| Scholar Dashboard | `2412:13539` | Scholar Panel (Mobile) |
| My Courses & Progress | `2412:13671` | Scholar Panel (Mobile) |
| Assignments | `2412:13759` | Scholar Panel (Mobile) |
| Resources | `2412:13835` | Scholar Panel (Mobile) |
| My Cohort | `2412:13901` | Scholar Panel (Mobile) |
| Chat | `2412:14004` | Scholar Panel (Mobile) |
| Profile & Settings | `2412:14076` | Scholar Panel (Mobile) |

**Figma file key:** `LOwDLoSh0qxmDH1VHuLO7w`
**Full URL:** https://www.figma.com/design/LOwDLoSh0qxmDH1VHuLO7w/Traq

---

## How to Pick Up From Here

1. Read `AGENTS.md` (project rules)
2. Read this file (what's built and what's next)
3. Check "What's In Progress" — don't duplicate someone else's work
4. Start the next unchecked item
5. Move it to "In Progress" with your name before you start
6. When done, check it off and commit this file with your PR
