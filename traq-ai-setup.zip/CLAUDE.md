@AGENTS.md


# ScholarLink — Frontend

## What this is

ScholarLink is a multi-tenant SaaS Program & Scholarship Management Platform. It allows organizations (NGOs, foundations, corporate learning programs) to manage scholars, mentors, programs, courses, assignments, attendance, and reporting from one centralized system.

**Pilot client:** Talent Makers Foundation (TMF), Lagos, Nigeria.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | Next.js (App Router) + React + TypeScript |
| Styling | Tailwind CSS |
| State — server | TanStack Query |
| State — auth | Controlled auth/session store |
| State — UI | React state / context (no global library unless justified) |
| Real-time | Socket.IO client (WebSocket notifications + dashboard updates) |
| PWA | Service worker + manifest (installable on Android, iOS, desktop) |
| Hosting | Vercel |
| API | REST `/api/v1` (internal) |
| Monorepo path | `/apps/web` |

---

## Architecture Rules

- **No direct DB access.** All data goes through the backend API.
- **Tenant context from session only.** Never pass `organizationId` from the browser as a trusted value — the API derives it from the authenticated session.
- **Server-side validation is authoritative.** Client validation is UX only, never a security boundary.
- **Offline writes are blocked.** High-integrity actions (Mark as Done, attendance, verification) must require connectivity. Show a clear offline banner, do not fake-queue writes.
- **PWA update strategy** must invalidate stale service worker cache on new releases.
- **UTC everywhere in API, timezone display in UI.** All timestamps come from the API in ISO 8601 UTC. Display converts to org/user timezone (default: `Africa/Lagos` for TMF).

---

## Three User Experiences

Do not build one generic shell with hidden menu items. Build three distinct experiences:

### Super Admin
- **Priority:** Information density + efficient administration
- **Navigation:** Dashboard · Programs · Courses · People (Scholars / Mentors) · Sort or Pair · Assignments · Attendance · Resources · Reports · Audit Log · Settings
- **Device priority:** Desktop-first, tablet fallback

### Mentor
- **Priority:** Speed + focused task completion
- **Navigation:** Dashboard · My Scholars · My Courses · Assignments · Resources · Attendance · Meetings
- **Device priority:** Mobile + tablet

### Scholar
- **Priority:** Simplicity + mobile usability
- **Navigation:** Home · Assignments · Resources · Meetings · Progress
- **Mobile bottom nav:** Home · Tasks · Resources · Progress · More
- **Device priority:** Mobile-first

---

## Key Product Rules (enforce in UI)

- Scholar progress = 70% assignment performance + 30% attendance (org-configurable weights)
- Assignment editing window = 60 minutes after publish → show countdown, replace Edit with "Request Change" after expiry
- Excused attendance does NOT count against attendance rate
- Late submissions reduce earned credit (default: 20% deduction)
- Scholars CANNOT see another scholar's progress, attendance %, assignment status, or mentor feedback
- Invitation links expire after 48 hours
- File upload max: 20 MB per file
- Assignment deadlines are mandatory — publish is blocked without one
- Archived programs/courses retain all historical data — never show as deleted

---

## Assignment Status Flow

```
NOT_STARTED → IN_PROGRESS → PENDING_VERIFICATION → VERIFIED / VERIFIED_LATE
                                                  → RESUBMISSION_REQUIRED → (loop)
                                                  → OVERDUE (parallel)
```

---

## API Conventions

Base path: `/api/v1`

Standard success envelope:
```json
{ "success": true, "data": {}, "meta": {} }
```

Standard error envelope:
```json
{ "success": false, "error": { "code": "MACHINE_READABLE_CODE", "message": "Human message." } }
```

Key error codes to handle in UI:
- `ASSIGNMENT_EDIT_WINDOW_EXPIRED`
- `INVITATION_EXPIRED`
- `TENANT_ACCESS_DENIED`
- `FILE_TOO_LARGE`
- `PERMISSION_DENIED`
- `AUTH_SESSION_EXPIRED` → redirect to login

Pagination: `?page=1&limit=25` with `meta.total` / `meta.totalPages` in response.

Async operations return `202 Accepted` with a `{ reportId, status: "PENDING" }` body — poll for completion.

---

## WebSocket Events (Socket.IO)

Connect after authentication. User joins room `user:{userId}`.

Key events to handle:
- `notification.created` → update bell badge, insert into notification list
- `assignment.verified` / `assignment.overdue` → update assignment status
- `analytics.course.updated` → refetch relevant dashboard query
- `meeting.created` / `meeting.updated` → update meetings list

Users must only receive events they are authorized for. Never allow client-side room subscriptions.

---

## Component & UX Rules

- **Tables** for: admin list views, filtering/sorting, bulk actions
- **Cards** for: scholar-facing content, mobile consumption
- **Empty states** must distinguish between "no data exists" and "filters returned nothing" — include a Clear Filters action in the latter case
- **Archive actions** must use the word "Archive" (not a trash icon alone) and show a confirmation explaining that historical data is preserved
- **Progress weights** settings must validate that assignment + attendance weights sum to 100% — show inline error immediately
- **At-risk messaging to scholars** should be constructive: "Your attendance is currently below the program target" — not a red "AT RISK" label
- **Dates/times** must show timezone where ambiguity exists (e.g., assignment deadlines)

---

## Available Skills

Use these skills by reading the corresponding file in `.claude/skills/`:

| Skill | File | When to use |
|---|---|---|
| Frontend Design | `frontend-design.md` | Building or redesigning any UI screen, component styling, layout decisions |
| Figma → Code | `figma-design-to-code.md` | Translating a Figma handoff into Next.js components — MUST read before calling `get_design_context` |
| Design System | `design-system.md` | Auditing component consistency, documenting component variants, extending the component library |
| Accessibility Review | `accessibility-review.md` | WCAG 2.1 AA audits before handoff — keyboard nav, contrast, screen reader, touch targets |
| Testing Strategy | `testing-strategy.md` | Planning component tests, E2E flows, coverage targets |
| Deploy Checklist | `deploy-checklist.md` | Pre-Vercel deploy verification, PWA cache invalidation, service worker version checks |
| Code Review | `code-review.md` | PR reviews — security, N+1 patterns, auth enforcement, TypeScript correctness |
| Tech Debt | `tech-debt.md` | Identifying and prioritizing refactor work |
| Standup | `standup.md` | Daily standup generation from recent activity |

---

## Monorepo Context

```
/apps/web          ← this repo (Next.js frontend)
/apps/api          ← backend (NestJS)
/packages/types    ← shared TypeScript types
/packages/config   ← shared config (eslint, tsconfig)
/packages/ui       ← shared UI primitives (if applicable)
```

Import shared types from `@scholarlink/types`. Never duplicate type definitions locally that exist in the shared package.

---

## Environment Variables

Never commit secrets. All environment variables go in the hosting platform config. Required vars:
- `NEXT_PUBLIC_API_URL` — backend API base URL
- `NEXT_PUBLIC_WS_URL` — WebSocket server URL
- `NEXT_PUBLIC_APP_ENV` — `development` | `staging` | `production`

---

## Definition of Done (Frontend)

A feature is complete when:
- [ ] UI is implemented and matches design
- [ ] Mobile breakpoint works (Scholar/Mentor flows)
- [ ] Loading state exists
- [ ] Empty state exists (true empty + filtered empty)
- [ ] Error state exists with actionable message
- [ ] Offline state is handled for write actions
- [ ] Client validation is present (backend remains authoritative)
- [ ] API integration is complete
- [ ] Role-based visibility is correct (not just hidden — unauthorized paths must not expose data)
- [ ] Component tests exist
- [ ] E2E test exists for critical flows
- [ ] Accessibility: keyboard navigable, labels present, contrast passes
- [ ] Reviewed and merged via PR
- [ ] Passes staging QA
