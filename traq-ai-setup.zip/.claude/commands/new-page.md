---
description: Scaffold a new Next.js App Router page for ScholarLink with layout, loading, and error boundaries
argument-hint: "<route-path> [role: admin|mentor|scholar]"
---

Create a new Next.js App Router page for ScholarLink: $ARGUMENTS

Parse the route path and role from the arguments.

## Route Group Mapping

- `admin` → `src/app/(admin)/`
- `mentor` → `src/app/(mentor)/`
- `scholar` → `src/app/(scholar)/`
- `auth` → `src/app/(auth)/`

## Files to Create

For a route `/{role}/{page-name}`, create:

**`src/app/({role})/{page-name}/page.tsx`** — Page component
```tsx
import { type Metadata } from 'next'

export const metadata: Metadata = {
  title: '{Page Name} | ScholarLink',
}

export default function {PageName}Page() {
  return (
    <{PageName}View />
  )
}
```

**`src/app/({role})/{page-name}/loading.tsx`** — Loading UI (Suspense boundary)
```tsx
export default function Loading() {
  return <{PageName}Skeleton />
}
```

**`src/app/({role})/{page-name}/error.tsx`** — Error boundary
```tsx
'use client'
import { type FC } from 'react'

interface ErrorProps {
  error: Error & { digest?: string }
  reset: () => void
}

const ErrorPage: FC<ErrorProps> = ({ error, reset }) => {
  return (
    <div role="alert">
      <p>Something went wrong loading this page.</p>
      <button onClick={reset}>Try again</button>
    </div>
  )
}

export default ErrorPage
```

**`src/components/{role}/{PageName}View/index.tsx`** — The actual view component (keeps page.tsx thin)

## Role-Specific Nav Check

After creating the page, remind me to:
- Add the route to the role's navigation config if it should appear in the sidebar/bottom nav
- Add the route to the auth guard / middleware so only the correct role can access it
- Add an E2E test for the page in `tests/e2e/{role}/`

Run `npx tsc --noEmit --skipLibCheck 2>&1 | head -20` after creating all files.
