---
description: Generate a pre-deploy checklist for ScholarLink FE to Vercel (staging or production)
argument-hint: "[staging|production] [release description]"
---

Generate a ScholarLink FE deploy checklist for: $ARGUMENTS

Read `.claude/skills/deploy-checklist.md` for the base checklist framework, then apply the ScholarLink-specific checks below.

## ScholarLink FE Deploy Checklist

**Target:** $ARGUMENTS
**Date:** (fill in)
**Deployer:** (fill in)

---

### Pre-Deploy — Code

- [ ] All PRs for this release are merged to the deploy branch
- [ ] Branch is up to date with `main`/`staging` (no diverged commits)
- [ ] `npm run type-check` passes with zero errors
- [ ] `npm run lint` passes with zero errors
- [ ] `npm run test` passes (all component + unit tests green)
- [ ] `npm run build` completes without errors
- [ ] No `console.error` or `console.warn` calls left in production code
- [ ] No hardcoded API URLs — all through environment variables
- [ ] No `NEXT_PUBLIC_*` variables exposing secrets

### Pre-Deploy — Environment

- [ ] Environment variables confirmed in Vercel dashboard for target environment
  - `NEXT_PUBLIC_API_URL` points to correct backend
  - `NEXT_PUBLIC_WS_URL` points to correct WebSocket server
  - `NEXT_PUBLIC_APP_ENV` = `staging` or `production`
- [ ] Backend API for target environment is deployed and healthy
- [ ] Backend health check passes: `curl {API_URL}/api/v1/health`

### Pre-Deploy — PWA

- [ ] Service worker version updated (if SW code changed)
- [ ] `manifest.json` icons and metadata correct
- [ ] Cache strategy reviewed — stale assets won't block users post-deploy

### Pre-Deploy — DB / API Contract

- [ ] If API shape changed: confirmed frontend handles both old and new response shapes during rollout window
- [ ] No breaking API changes deployed to production without frontend ready

### Deploy

- [ ] Merge / trigger Vercel deployment
- [ ] Watch build logs — confirm no warnings that could affect runtime
- [ ] Confirm deployment URL is live

### Post-Deploy — Smoke Tests

Run these manually on the deployed URL:

- [ ] Login works (email + password)
- [ ] Invitation link flow works end-to-end
- [ ] Admin dashboard loads with correct metrics
- [ ] Mentor can view assignments and verification queue
- [ ] Scholar can view assignments and mark as done
- [ ] WebSocket notifications arrive in real time (trigger an action and check bell)
- [ ] PWA install prompt appears on supported devices (Android Chrome)
- [ ] File upload (resource) works up to 20 MB
- [ ] Offline banner shows when network is disabled

### Post-Deploy — Monitoring

- [ ] Sentry error rate is flat (no spike in the 15 min after deploy)
- [ ] Vercel analytics showing expected traffic pattern
- [ ] No console errors in browser dev tools on key pages

### Rollback Triggers

Roll back immediately if:
- Login is broken for any role
- Sentry error rate increases > 5% vs pre-deploy baseline
- Assignment Mark as Done or Verification flow is broken
- Admin dashboard is blank or shows wrong data
- WebSocket connection fails to establish

**Rollback command:** Redeploy previous Vercel deployment from the Vercel dashboard → Deployments → Promote previous build.
