---
description: Code review a ScholarLink FE file, component, or PR diff focused on security, correctness, and ScholarLink-specific rules
argument-hint: "<file path, component name, or git diff>"
---

Review this for the ScholarLink frontend: $ARGUMENTS

Read `.claude/skills/code-review.md` for the review framework, then apply ScholarLink-specific checks below.

## ScholarLink FE Review Checklist

### Security & Privacy
- [ ] Scholar data: does any component expose another scholar's progress %, attendance %, assignment status, or mentor feedback?
- [ ] Auth: are protected routes guarded both in middleware AND in the component (not just one)?
- [ ] Tokens: no access/refresh tokens in `localStorage` or `sessionStorage`
- [ ] API calls: no `organizationId` sent from client as a trusted value
- [ ] Env vars: no secrets in `NEXT_PUBLIC_*` variables

### Data Fetching
- [ ] All server state through TanStack Query (no raw `fetch` in components)
- [ ] Loading states handled — no blank screens while data loads
- [ ] Error states handled — specific, actionable messages (not generic "Something went wrong")
- [ ] Stale data: are cache invalidations triggered after mutations?

### TypeScript
- [ ] No `any` types
- [ ] No `as unknown as X` unsafe casts
- [ ] Props interfaces defined in separate `types.ts` files
- [ ] Shared types imported from `@scholarlink/types` (not redefined locally)

### Business Logic
- [ ] Assignment edit window: does it use server-derived `editWindowExpiresAt`, not a client-calculated time?
- [ ] Late status: never computed client-side — comes from API (`isLate` field)
- [ ] Progress weights: if rendered, do they validate that assignment + attendance sum to 100%?
- [ ] Excused attendance: confirmed excluded from rate calculation display?
- [ ] Offline writes: are Mark as Done / attendance / verification blocked when offline?

### Accessibility
- [ ] Interactive elements have accessible labels
- [ ] Form inputs paired with labels
- [ ] Errors linked via `aria-describedby`
- [ ] Keyboard navigable
- [ ] Touch targets ≥ 44×44px on mobile components

### Component Quality
- [ ] All states handled: loading, empty (true + filtered), error, offline
- [ ] Empty state distinguishes "no data" from "filters returned nothing"
- [ ] Archive/destructive actions use descriptive labels with confirmation
- [ ] Real-time updates (WebSocket events) handled without full page reload

## Output Format

Use the format from `.claude/skills/code-review.md`:
- Critical Issues table (🔴)
- Suggestions table (🟡)
- What Looks Good
- Verdict: Approve / Request Changes / Needs Discussion
