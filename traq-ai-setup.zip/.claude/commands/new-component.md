---
description: Scaffold a new ScholarLink React component with types, tests, and barrel export
argument-hint: "<ComponentName> [role: admin|mentor|scholar|shared]"
---

Create a new ScholarLink component: $ARGUMENTS

Follow these steps:

1. Parse the component name and target role from the arguments. If role is not specified, default to `shared`.

2. Determine the correct directory:
   - `shared` → `src/components/shared/{ComponentName}/`
   - `admin` → `src/components/admin/{ComponentName}/`
   - `mentor` → `src/components/mentor/{ComponentName}/`
   - `scholar` → `src/components/scholar/{ComponentName}/`

3. Create the following files:

**`types.ts`** — Props interface
```ts
export interface {ComponentName}Props {
  // Define props here
}
```

**`index.tsx`** — Component
- TypeScript strict (no `any`)
- Tailwind for styling (no inline styles, no arbitrary hex values)
- Must handle: loading state, empty state, error state
- If it contains write actions: handle offline state
- Accessible: proper roles, labels, keyboard support

**`{ComponentName}.test.tsx`** — Test scaffold
- Import from `@/test-utils` (not directly from @testing-library/react)
- Include test cases for: renders, loading state, empty state, error state, key user interactions

**`index.ts`** — Barrel export
```ts
export { ComponentName } from './index'
export type { ComponentNameProps } from './types'
```

4. State each file path explicitly before writing it.

5. After creating the files, run `npx tsc --noEmit --skipLibCheck 2>&1 | head -20` to confirm no type errors.
